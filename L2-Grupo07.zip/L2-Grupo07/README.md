# Laboratorio 2 - INF256

### Integrantes:

Martin Ibañez, ROL: 202273597-K

Benjamín Urrutia, ROL: 202273580-5

David Kripper, ROL: 202273521-K

### Instrucciones de uso

Requisitos para la ejecución:

* Tener Python 3.1.0 o superior instalado.

Ejecución:

Terminal 1
```
python3 run_lab2.py
```
De igual forma hay que estar conectados a la red del laboratorio de redes B049 para poder realizar el flujo completo.

### Bibliografía

En el informe 😁.